var mergeJSON = require("merge-json") ;
var merge = require('deepmerge');
var convert = require('xml-js');

var json1;
var json2;

var fs = require('fs');

loadFile('/data/xml1.xml',loadFile1);

function loadFile1 (err, data) {
  if (err) {
    throw err; 
  }
    
  json1 = convert.xml2json(data, {compact: true, spaces: 4});
    
   // console.log(json1);
  loadFile('/data/xml2.xml',loadFile2);
}

function loadFile2 (err, data) {
  if (err) {
    throw err; 
  }
 
  json2 = convert.xml2json(data, {compact: true, spaces: 4});
  var result = customMerge(JSON.parse(json1), JSON.parse(json2));
    // var result =merge(JSON.parse(json1), JSON.parse(json2));
     console.log(convert.json2xml(result, {compact: true, spaces: 4})); 
  //merge(json1,json2);
}

function loadFile(fileName,callBack){
  fs.readFile( __dirname + fileName,  callBack);
}

function merge(one,two){
    console.log('sdfsf');
    console.log(one);
    console.log(two);
   var result = merge(JSON.parse(one), JSON.parse(two));
   
   console.log(JSON.stringify(result)); 
}


function customMerge(json1,json2){
  result = {} ;

  for(var key in json1){
    result[key] = json1[key] ;
  }
  
  for(var key in json2){
    if(typeof result[key] === "object" && typeof json2 === "object"){
      result[key] = customMerge(result[key], json2[key]) ;
    }else{
      result[key] = json2[key] ;
    }
  }

  return result;
}






/*var result = mergeJSON.merge(obj1, obj2) ;
console.log(JSON.stringify(result)) ;*/